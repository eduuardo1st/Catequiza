package com.catequiza.admin.domain;

import com.catequiza.admin.controllers.dto.DadosCadastroTurma;
import com.catequiza.admin.controllers.dto.DadosAtualizacaoTurma;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "turma")
public class Turma {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "catequista_id", nullable = false)
    private Catequista catequista;

    @Column(name = "nome_turma", nullable = false)
    private String nomeTurma;

    @Column(name = "ano_letivo", nullable = false)
    private Integer anoLetivo;

    public Turma() {
    }

    public Turma(DadosCadastroTurma dados, Catequista catequista) {
        this.catequista = catequista;
        this.nomeTurma = dados.nomeTurma();
        this.anoLetivo = dados.anoLetivo();
    }

    public void atualizarInformacoes(DadosAtualizacaoTurma dados) {
        if (dados.nomeTurma() != null) {
            this.nomeTurma = dados.nomeTurma();
        }
        if (dados.anoLetivo() != null) {
            this.anoLetivo = dados.anoLetivo();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Catequista getCatequista() {
        return catequista;
    }

    public void setCatequista(Catequista catequista) {
        this.catequista = catequista;
    }

    public String getNomeTurma() {
        return nomeTurma;
    }

    public void setNomeTurma(String nomeTurma) {
        this.nomeTurma = nomeTurma;
    }

    public Integer getAnoLetivo() {
        return anoLetivo;
    }

    public void setAnoLetivo(Integer anoLetivo) {
        this.anoLetivo = anoLetivo;
    }
}
