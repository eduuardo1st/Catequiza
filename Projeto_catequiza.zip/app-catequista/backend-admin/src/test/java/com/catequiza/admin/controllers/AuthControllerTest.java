package com.catequiza.admin.controllers;

import com.catequiza.admin.repositories.*;
import com.catequiza.admin.domain.*;
import com.catequiza.admin.controllers.dto.*;
import com.catequiza.admin.security.TokenService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthController.class)
@AutoConfigureMockMvc(addFilters = false)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private TokenService tokenService;

    @Test
    void loginComCredenciaisValidasDeveRetornar200() throws Exception {
        var dadosLogin = """
                {
                    "email": "admin@teste.com",
                    "senha": "123456"
                }
                """;

        var catequista = new Catequista();
        catequista.setEmail("admin@teste.com");

        Authentication authentication = new UsernamePasswordAuthenticationToken(catequista, null);
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(tokenService.gerarToken(any(String.class))).thenReturn("token-jwt-teste");

        mockMvc.perform(post("/login")
                        .contentType("application/json")
                        .content(dadosLogin))
                .andExpect(status().isOk());
    }
}
