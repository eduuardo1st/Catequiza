package com.catequiza.admin.controllers;

import com.catequiza.admin.repositories.*;
import com.catequiza.admin.domain.*;
import com.catequiza.admin.controllers.dto.*;
import com.catequiza.admin.security.TokenService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(MatriculaController.class)
@AutoConfigureMockMvc(addFilters = false)
class MatriculaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MatriculaTurmaRepository matriculaTurmaRepository;

    @MockBean
    private CatequizandoRepository catequizandoRepository;

    @MockBean
    private TurmaRepository turmaRepository;

    @MockBean
    private TokenService tokenService;

    @Test
    void cadastrarMatriculaDeveRetornar201() throws Exception {
        var catequizando = new Catequizando();
        catequizando.setMatricula(1L);
        catequizando.setNome("João Silva");

        var turma = new Turma();
        turma.setId(1L);
        turma.setNomeTurma("Turma Batismo");

        when(catequizandoRepository.findById(anyLong())).thenReturn(Optional.of(catequizando));
        when(turmaRepository.findById(anyLong())).thenReturn(Optional.of(turma));

        var dadosCadastro = """
                {
                    "matriculaCatequizando": 1,
                    "idTurma": 1,
                    "statusMatricula": "ATIVA"
                }
                """;

        mockMvc.perform(post("/matriculas")
                        .contentType("application/json")
                        .content(dadosCadastro))
                .andExpect(status().isCreated());
    }

    @Test
    void listarMatriculasDeveRetornar200() throws Exception {
        mockMvc.perform(get("/matriculas"))
                .andExpect(status().isOk());
    }
}
